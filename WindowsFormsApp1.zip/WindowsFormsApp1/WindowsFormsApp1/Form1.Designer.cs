﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listbx_makanan = new System.Windows.Forms.ListBox();
            this.combo_tmpt = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbl_tmpt = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.txtbx_makanan = new System.Windows.Forms.TextBox();
            this.txtbx_tmpt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_choose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listbx_makanan
            // 
            this.listbx_makanan.FormattingEnabled = true;
            this.listbx_makanan.Location = new System.Drawing.Point(242, 221);
            this.listbx_makanan.Name = "listbx_makanan";
            this.listbx_makanan.Size = new System.Drawing.Size(120, 95);
            this.listbx_makanan.TabIndex = 0;
            // 
            // combo_tmpt
            // 
            this.combo_tmpt.FormattingEnabled = true;
            this.combo_tmpt.Location = new System.Drawing.Point(377, 221);
            this.combo_tmpt.Name = "combo_tmpt";
            this.combo_tmpt.Size = new System.Drawing.Size(168, 21);
            this.combo_tmpt.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(505, 75);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(159, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // lbl_tmpt
            // 
            this.lbl_tmpt.AutoSize = true;
            this.lbl_tmpt.Location = new System.Drawing.Point(141, 162);
            this.lbl_tmpt.Name = "lbl_tmpt";
            this.lbl_tmpt.Size = new System.Drawing.Size(78, 13);
            this.lbl_tmpt.TabIndex = 4;
            this.lbl_tmpt.Text = "Tempat makan";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(428, 136);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 6;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // txtbx_makanan
            // 
            this.txtbx_makanan.Location = new System.Drawing.Point(242, 136);
            this.txtbx_makanan.Name = "txtbx_makanan";
            this.txtbx_makanan.Size = new System.Drawing.Size(168, 20);
            this.txtbx_makanan.TabIndex = 7;
            // 
            // txtbx_tmpt
            // 
            this.txtbx_tmpt.Location = new System.Drawing.Point(242, 162);
            this.txtbx_tmpt.Name = "txtbx_tmpt";
            this.txtbx_tmpt.Size = new System.Drawing.Size(168, 20);
            this.txtbx_tmpt.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(141, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "makan";
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(161, 221);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 23);
            this.btn_clear.TabIndex = 10;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(161, 250);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 11;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_choose
            // 
            this.btn_choose.Location = new System.Drawing.Point(161, 279);
            this.btn_choose.Name = "btn_choose";
            this.btn_choose.Size = new System.Drawing.Size(75, 23);
            this.btn_choose.TabIndex = 12;
            this.btn_choose.Text = "Pilih";
            this.btn_choose.UseVisualStyleBackColor = true;
            this.btn_choose.Click += new System.EventHandler(this.btn_choose_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_choose);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtbx_tmpt);
            this.Controls.Add(this.txtbx_makanan);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.lbl_tmpt);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.combo_tmpt);
            this.Controls.Add(this.listbx_makanan);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listbx_makanan;
        private System.Windows.Forms.ComboBox combo_tmpt;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbl_tmpt;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.TextBox txtbx_makanan;
        private System.Windows.Forms.TextBox txtbx_tmpt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_choose;
    }
}

