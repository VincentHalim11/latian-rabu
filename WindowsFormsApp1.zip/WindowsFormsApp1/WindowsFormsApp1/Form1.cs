﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        DataTable dtmakanan = new DataTable();



        public Form1()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            listbx_makanan.Items.Add(txtbx_makanan.Text);
            combo_tmpt.Items.Add(txtbx_tmpt.Text);

            txtbx_tmpt.Clear();
            txtbx_makanan.Clear();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            listbx_makanan.Items.Clear();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            listbx_makanan.Items.Remove(listbx_makanan.Text);
        }

        private void btn_choose_Click(object sender, EventArgs e)
        {
            int indexdata = listbx_makanan.SelectedIndex;
            int hehehe = Convert.ToInt32(dtmakanan.Rows[indexdata][2].ToString());
            string urutan1 = dtmakanan.Rows[indexdata][0].ToString();
            string urutan2 = dtmakanan.Rows[indexdata][1].ToString();
            string urutan3 = hehehe.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
            //tampilan contoh : A001 - Ayam Goreng  Rp. 50.000 (lat pak ct)
            MessageBox.Show($"{urutan1} - {urutan2} {urutan3}");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtmakanan.Columns.Add("ID Makanan");
            dtmakanan.Columns.Add("Nama Makanan");
            dtmakanan.Columns.Add("Harga Makanan");

            dtmakanan.Rows.Add("A001", "Ayam Goreng", "50000");
            dtmakanan.Rows.Add("A002", "Gado-Gado", "20000");
            dtmakanan.Rows.Add("A003", "Indomie", "100000");
            dtmakanan.Rows.Add("A004", "Xiaolong Bao", "90000");
            dtmakanan.Rows.Add("A005", "Masakan Rumah", "Gratis");

            listbx_makanan.DataSource = dtmakanan;
            listbx_makanan.DisplayMember = "Nama Makanan";
            //listbx_makanan.ValueMember = "ID Makanan";
        }
    }
}
